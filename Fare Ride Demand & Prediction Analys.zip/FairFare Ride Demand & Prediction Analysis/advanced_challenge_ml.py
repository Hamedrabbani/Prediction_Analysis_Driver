import pandas as pd
from sklearn.linear_model import LinearRegression
import numpy as np
import matplotlib.pyplot as plt


df = pd.read_csv("fairfare_ride_demand_dataset (1).csv")

all_results = []
         # Extraction of cities
cities = df["City"].unique()

        # Forecast for each city
for city in cities:

        # Filter the dataframe by city and use copy() to avoid the warning
    df_city = df[df["City"] == city].copy()
    
        # Convert the date column to datetime type and calculate the Day_Index for the dataframe for that city:

    df_city["Date"] = pd.to_datetime(df_city["Date"],format="%d-%m-%Y")
    df_city["Day_Index"] = df_city["Date"].dt.dayofyear
    
        # Preparing data for the model
    X = df_city[["Day_Index"]]
    y = df_city["Final_Fare"]
    
        # Create and train a linear regression model
    model = LinearRegression()
    model.fit(X, y)
    
        # Forecast for the coming days based on data from the same city
    forecast_coming_days = np.arange(df_city["Day_Index"].max() + 1,df_city["Day_Index"].max() + 10).reshape(-1, 1)
    predicting_future = model.predict(forecast_coming_days)
    print(f"\n Show predictions for city : {city}")

    
        # Display forecasts as day number (Day_Index)
    for day, pred in zip(forecast_coming_days.flatten(),predicting_future):
        print(f"  Projected revenue for  {day} : {pred:.2f}")

        # Get the latest available date for the corresponding city
    max_date = df_city["Date"].max()
    print(f"\n  Latest date for  {city}: {max_date.strftime('%Y-%m-%d')}")

    
        # Generate future dates: from 1 to 9 days after the last available date:
    future_dates = [max_date + pd.Timedelta(days=i) for i in range(1, 10)]

    
        # Combination of actual dates and managed forecast:
    for day, date, predicting in zip( forecast_coming_days.flatten(), future_dates,predicting_future):
        all_results.append({"City": city, "Date": date.strftime('%Y-%m-%d'), "Day_Index": day, "Predicted_Fare": predicting})

        
        # Saving the output to CSV file and the forecast for the next 9 days for each city:
final_results_df = pd.DataFrame(all_results)
final_results_df.to_csv("all_cities_future_predictions.csv", index=True)


        # This code draws a line of the daily fare amount:
df.groupby("Date")["Final_Fare"].mean().plot(kind="line", title="Daily Fare Amount")
plt.show()

        # This code calculates the average fare for each hour of the day and then displays it as a bar chart:
df.groupby("Hour_of_Day")["Final_Fare"].mean().plot(kind="bar", title="Hourly Fare Amount")
plt.show()



