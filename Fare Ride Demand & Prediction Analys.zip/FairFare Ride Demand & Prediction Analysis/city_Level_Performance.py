from sklearn.linear_model import LinearRegression
import pandas as pd

df = pd.read_csv("fairfare_ride_demand_dataset (1).csv")


        #show total large cities with similar income:
free_city = df.groupby("City")['Final_Fare'].sum()
top_fare_by_city_sum_sorted = free_city.sort_values(ascending=False).head(10)
        # Create a sorted table
top_fare_city_sum = pd.DataFrame({
    "City": top_fare_by_city_sum_sorted .index, 
    "total free (INR)": top_fare_by_city_sum_sorted .values
})
        # show table
print(top_fare_city_sum)


        # Add currency name:
df["Final_Fare_Display"] = df["Final_Fare"].apply(lambda x: f"{x} INR")
currency_conversion = df[["Final_Fare", "Final_Fare_Display"]]
print(currency_conversion)

        # Calculate The highest fare by city:
fare_city = df.groupby("City")['Final_Fare'].max()
top_free = free_city.sort_values(ascending=False)

        # Create a sorted table
top_fare_city_max = pd.DataFrame({
    "City":top_free .index, 
    "total free (INR)": top_free.values
})
        # show table
print(top_fare_city_max)



# Saving the output to another file as CSV:

final_results_df = pd.DataFrame(top_fare_city_sum)
final_results_df.to_csv("top_fare_city.csv", index=False)
final_results_df = pd.DataFrame(currency_conversion)
final_results_df.to_csv("currency_conversion.csv", index=False)
final_results_df = pd.DataFrame(top_fare_city_max)
final_results_df.to_csv("top_fare_city_max.csv", index=False)



