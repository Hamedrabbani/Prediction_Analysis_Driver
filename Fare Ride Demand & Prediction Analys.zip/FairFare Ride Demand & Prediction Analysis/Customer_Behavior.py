from sklearn.linear_model import LinearRegression
import pandas as pd 

df = pd.read_csv("fairfare_ride_demand_dataset (1).csv")
     
        # Identify rides with exceptionally low driver ratings :

Distance_km= df.groupby("City")['Driver_Performance_Score'].max()
top_score_drivers = Distance_km.sort_values(ascending=False)

        # Create a sorted table
top_score_driver = pd.DataFrame({
    "City": top_score_drivers .index, 
    "score drivers": top_score_drivers.values
})

        # show table
print(top_score_driver)


        # show calculate the percentage of passengers accepted by drivers in each city.

df["Fare_Acceptance_Percentage"] = df["Fare_Acceptance"] * 100
Acceptance_percentage=df[["City","Fare_Acceptance", "Fare_Acceptance_Percentage"]]
print(Acceptance_percentage)

 
# Saving the output to another file as CSV:
final_results_df = pd.DataFrame(top_score_driver)
final_results_df.to_csv("top_score_driver.csv", index=False)

final_results_df = pd.DataFrame(Acceptance_percentage)
final_results_df.to_csv("Acceptance_percentage.csv", index=False)

