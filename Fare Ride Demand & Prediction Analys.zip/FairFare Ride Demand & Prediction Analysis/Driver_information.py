from sklearn.linear_model import LinearRegression
import pandas as pd
import csv


df = pd.read_csv("fairfare_ride_demand_dataset (1).csv")
# Display header for easy reading
data = "fairfare_ride_demand_dataset (1).csv"

with open(data,'r') as file_ride:
    csv_file = csv.reader(file_ride)
    next_header = next(csv_file)
    for header in next_header:
        print(header)
    print("\t")



        # Find the top 10 drivers with the highest average ratings (based on Driver_Rating):


filtered_90_score = df[df["Driver_Performance_Score"] > 90][["City", "Driver_Performance_Score"]]
print(filtered_90_score.head(10)) 
print(df["Driver_Performance_Score"].describe()) # Display average, minimum and maximum values.


        # Identify drivers with the most rides completed :

df["Ride_Distance_KM"] = df["Ride_Distance_KM"] * 1.60934  # Convert miles to kilometers
df["Ride_Distance_KM"] = df["Ride_Distance_KM"].round(2)  # Rounding a value to two decimal places



filtered_df = df[df["Ride_Distance_KM"] > 25][["City", "Ride_Distance_KM"]] # 10 cities or drivers who traveled more than 25 kilometers:
print(filtered_df.head(10)) 

top_driver_city_sum = df.groupby("City")["Ride_Distance_KM"].sum() # show Total distances of the cities Which has been traveled by drivers.
top_driver_city_max = df.groupby("City")["Ride_Distance_KM"].max() # show the most distances of the cities Which has been traveled by drivers.
top_driver_city_min = df.groupby("City")["Ride_Distance_KM"].min() # show the least distances of the cities Which has been traveled by drivers.

top_driver_city_sum_sorted = top_driver_city_sum.sort_values(ascending=False) #For greater readability

df_top_distances_sum = pd.DataFrame({
    "City": top_driver_city_sum_sorted.index, 
    "Total Distance (KM)": top_driver_city_sum_sorted.values
})
# show table

print(df_top_distances_sum)


top_driver_by_city_sum_sorted = top_driver_city_min.sort_values(ascending=False).head(10)

# ساخت یک جدول مرتب‌شده
df_top_distances_min = pd.DataFrame({
    "City": top_driver_by_city_sum_sorted.index, 
    "Min Distance (KM)": top_driver_by_city_sum_sorted.values
})

# show table
print(df_top_distances_min)

top_driver_city_max_sorted = top_driver_city_max.sort_values(ascending=False).head(10)

# ساخت یک جدول مرتب‌شده
df_top_distances_max = pd.DataFrame({
    "City": top_driver_city_max_sorted.index, 
    "Max Distance (KM)": top_driver_city_max_sorted.values
})

# show table
print(df_top_distances_max)




        # Shows the 10 most traveled distances in each city:
top_city = sorted(top_driver_city_sum , key = lambda x: x,reverse = True)[:10]
print("The top 10 drivers with the most rides completed : \t" + str(top_city)) 


        # Top 10 drivers with the most miles traveled :
most_rides_km = df["Ride_Distance_KM"]
priority_10_KM= sorted(most_rides_km , key = lambda x: x,reverse = True)[:10]
print("The top 10 drivers with the most rides completed : \t" + str(priority_10_KM)) 

        # optional:
more_KM = df[df["Ride_Distance_KM"] > 30][["City", "Ride_Distance_KM"]] # Shows any city that is more than 30 kilometers away.

long_distance = df[df["Ride_Distance_KM"] > 20] # shows all the information of those who drive more than 20 kilometers per day.
short_distance = df[df["Ride_Distance_KM"] < 1] # shows all the information of those who drive less than 1 kilometers per day.
print(long_distance)  
print(more_KM)

        #show Average percentage, distance traveled
KM=df["Ride_Distance_KM"].describe() # Display average, minimum and maximum values.
city_percentage_sorted = KM.sort_values(ascending=False).head(10)

# Create a sorted table
persnt_KM = pd.DataFrame({
    "percentage": city_percentage_sorted .index, 
    "(KM)": city_percentage_sorted .values
})
# show table
print(persnt_KM)


results_df = filtered_90_score.merge(df_top_distances_sum, on="City", how="left") \
                              .merge(df_top_distances_max, on="City", how="left") \
                              .merge(df_top_distances_min, on="City", how="left")

# ذخیره فایل CSV
results_df.head(10).to_csv("processed_fairfare_results.csv", index=False)

